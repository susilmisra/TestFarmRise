package com.climate.farmrise.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

import java.util.List;

public class AccessWehterDetails extends Page {

    @AndroidFindBy(xpath = "//*[contains(@resource-id,horizontal)]")
    public MobileElement horizontalScrollElement;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,listOfTiming)]")
    public List<MobileElement> listOfTimings;


    public AccessWehterDetails(AppiumDriver driver) {
        super(driver);
    }


}
