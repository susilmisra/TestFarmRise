package com.climate.farmrise.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class ChoosePrefferedLanguagePage extends Page {
    @AndroidFindBy(xpath = "//*[contains(@resource-id,language) and @text='English']")
    public MobileElement englishLanguage;

    public ChoosePrefferedLanguagePage(AppiumDriver driver) {
        super(driver);
    }

}
