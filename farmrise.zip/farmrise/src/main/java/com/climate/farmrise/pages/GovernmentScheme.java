package com.climate.farmrise.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

import java.util.List;

public class GovernmentScheme extends Page {
    @AndroidFindBy(xpath = "//*[contains(@resource-id,loadMoresheme)]")
    public MobileElement loadMoreSchemeButton;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,vertical)]")
    public MobileElement verticalScrollElement;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,searchbutton)]")
    public MobileElement searchButton;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,searchtextfiled)]")
    public MobileElement searchTextField;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,searchList)]")
    public List<MobileElement> searchList;


    public GovernmentScheme(AppiumDriver driver) {
        super(driver);
    }
}
