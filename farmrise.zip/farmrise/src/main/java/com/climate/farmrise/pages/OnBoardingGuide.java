package com.climate.farmrise.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class OnBoardingGuide extends PermissionPoup{
    @AndroidFindBy(xpath = "//*[contains(@resource-id,OK) and @text='OK']")
    public MobileElement okButton;

    public OnBoardingGuide(AppiumDriver driver) {
        super(driver);
    }

    public boolean isValid() {
        try {
            if (okButton.isDisplayed()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

}
