package com.climate.farmrise.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class Tab extends Page {
    @AndroidFindBy(xpath = "//*[contains(@resource-id,home) and @text='Home']")
    public MobileElement homeTab;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,more) and @text='More']")
    public MobileElement moreTab;

    @AndroidFindBy(xpath = "//*[contains(@resource-id,mandi) and @text='Mandi']")
    public MobileElement mandiTab;
    public Tab(AppiumDriver driver) {
        super(driver);
    }
}
