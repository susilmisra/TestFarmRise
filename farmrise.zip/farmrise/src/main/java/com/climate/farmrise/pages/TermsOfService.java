package com.climate.farmrise.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class TermsOfService extends Page{
    @AndroidFindBy(xpath = "//*[contains(@resource-id,agree) and @text='Agree and Continue']")
    public MobileElement acceptAndContinue;

    public TermsOfService(AppiumDriver driver) {
        super(driver);
    }
}
