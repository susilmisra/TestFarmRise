package com.climate.farmrise.tests;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.ITestContext;

import java.net.MalformedURLException;
import java.net.URL;

public class Driver {
    private static String APPIUM_SERVER_IP;
    private static String APPIUM_PORT;
    private static String APPIUM_SERVER_URL;
    private static AppiumDriverLocalService service;
    private static AppiumServiceBuilder builder;
    private static DesiredCapabilities cap;
    static AppiumDriver driver;

    /**
     * starts appium server.
     *
     * @param context context
     * @throws InterruptedException error
     */
    public static void startAppiumServer(ITestContext context) throws InterruptedException {
        APPIUM_SERVER_IP = context.getCurrentXmlTest().getParameter("appium.server");
        APPIUM_PORT = context.getCurrentXmlTest().getParameter("appium.server.port");
        APPIUM_SERVER_URL = String.format("http://%s:%s/wd/hub/status", APPIUM_SERVER_IP, APPIUM_PORT);
        cap = new DesiredCapabilities();
        cap.setCapability("noReset", "false");
        builder = new AppiumServiceBuilder();
        builder.withIPAddress(APPIUM_SERVER_IP);
        builder.usingPort(Integer.parseInt(APPIUM_PORT));
        builder.withCapabilities(cap);
        builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
        builder.withArgument(GeneralServerFlag.LOG_LEVEL, "error");

        //Start the server with the builder
        service = AppiumDriverLocalService.buildService(builder);
        if (getAppiumServerStatus()) {
            service.stop();
        }
        service.start();

        for (int i = 0; i < 25; i++) {
            if (getAppiumServerStatus()) {
                break;
            } else {
                Thread.sleep(1000);
            }
        }
    }

    /**
     * stop appium.
     */
    public static void stopAppiumServer() {
        if (service != null) {
            service.stop();
        }
    }

    public static boolean getAppiumServerStatus() {
        return (service != null && service.isRunning());
    }

    private static DesiredCapabilities createDesiredCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION, "1.8");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Samsung S4");
        capabilities.setCapability(MobileCapabilityType.APP, System.getProperty("use.dir")+"\\download\\climateFarm.apk");
        capabilities.setCapability(MobileCapabilityType.UDID, "7ghu678");
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 999999);
        String automationname = "UiAutomator2";
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, automationname);
            capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.climate.farmrise");
            capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.climate.farmrise.splash");
            capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, "com.climate.farmrise.splash");
        return capabilities;
    }

    public static AppiumDriver createAppiumDriver() {
        URL server = null;
        DesiredCapabilities capabilities;
            capabilities = createDesiredCapabilities();
            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
        try {
            server = new URL(APPIUM_SERVER_URL);
                return new AndroidDriver(server, capabilities);

        } catch (MalformedURLException e) {
            Assert.fail("Mal formed url");
        } catch (Exception e) {
            String msg = "Exception occurred while creating appium driver";
            Assert.fail("Exception occurred while creating appium driver");
        }

        return null;
    }

    public static void setAppiumDriver(AppiumDriver thisdriver) {
        driver = thisdriver;
    }

    public static AppiumDriver<MobileElement> getAppiumDriver() {
        return driver;
    }

    public static void stopAppiumDriver() {
            AppiumDriver<MobileElement> driver = getAppiumDriver();
            if (driver != null) {
                try {
                        driver.closeApp();
                    driver.quit();
                } catch (Exception e) {
                }
            }
    }



}
