package com.climate.farmrise.tests;

import io.appium.java_client.AppiumDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class TestIntiate {
    protected AppiumDriver driver;

    /**
     * before suite.
     *
     * @param context context
     */
    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(ITestContext context) {
        try {
            Driver.startAppiumServer(context);
        } catch (Exception e) {

        }
    }

    /**
     * before test.
     *
     * @param context context
     */
    @BeforeTest
    public void beforeTest(ITestContext context) {
        Driver.createAppiumDriver();
        driver = Driver.getAppiumDriver();
    }
    /**
     * after test.
     *
     * @param context context
     */
    @AfterTest
    public void afterTest(ITestContext context) {
        Driver.stopAppiumDriver();
    }

}
