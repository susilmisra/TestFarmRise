package com.climate.farmrise.tests;

import com.climate.farmrise.pages.*;
import io.appium.java_client.MobileElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class VerifyAccessWetherTiming extends TestIntiate {

    @Test
    public void testFarm() {
        ChoosePrefferedLanguagePage choosePrefferedLanguagePage = new ChoosePrefferedLanguagePage(driver);
        choosePrefferedLanguagePage.click(choosePrefferedLanguagePage.englishLanguage);
        TermsOfService termsOfService = new TermsOfService(driver);
        termsOfService.click(termsOfService.acceptAndContinue);
        PickCrops pickCrops = new PickCrops(driver);
        pickCrops.click(pickCrops.pickCrop);
        pickCrops.click(pickCrops.proced);
        AllowLocationAccess allowLocationAccess = new AllowLocationAccess(driver);
        allowLocationAccess.click(allowLocationAccess.allowAndproced);
        PermissionPoup permissionPoup = new PermissionPoup(driver);
        permissionPoup.click(permissionPoup.allow);
        OnBoardingGuide onBoardingGuide = new OnBoardingGuide(driver);
        if (onBoardingGuide.isValid()) {
            while (onBoardingGuide.isValid()) {
                onBoardingGuide.click(onBoardingGuide.okButton);
            }
        }
        Tab tab = new Tab(driver);
        tab.click(tab.homeTab);
        HomeTab homeTab = new HomeTab(driver);
        homeTab.click(homeTab.acessWetherDetails);
        AccessWehterDetails accessWehterDetails = new AccessWehterDetails(driver);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh");
        SimpleDateFormat simpleDateAmPm = new SimpleDateFormat("aa");
        String nowTimeHour = simpleDateFormat.format(new Date());
        String nowTimeAmPm = simpleDateAmPm.format(new Date());
        List<String> listOfExpectedTiming = new ArrayList<String>();
        listOfExpectedTiming.add("Now");
        int nextTimeHr;
        String setMeridian;
        for (int i=1;i< 12;i++) {
            if (nowTimeHour.equalsIgnoreCase("12")) {
                nextTimeHr = Integer.parseInt(nowTimeHour)-11;
                if (nowTimeAmPm.equalsIgnoreCase("Am")) {
                    setMeridian="Pm";
                } else {
                    setMeridian="Am";
                }

            } else {
                nextTimeHr = Integer.parseInt(nowTimeHour) + i;
                setMeridian = nowTimeAmPm;
            }
            listOfExpectedTiming.add(nextTimeHr+" "+setMeridian);

        }

        int start = accessWehterDetails.horizontalScrollElement.getLocation().getX();
        int end = accessWehterDetails.horizontalScrollElement.getLocation().getX()/4;
        List<String> listOfTimingFromUi = new ArrayList<String>();
        String firstTimeBeforeScroll;
        String text;
            List<MobileElement> timingsList = accessWehterDetails.listOfTimings;

            if (timingsList == null || timingsList.size() <= 0) {
                Assert.fail("No timing present");
            }
            firstTimeBeforeScroll = timingsList.get(0).getText().trim();

            for (MobileElement time : timingsList) {
                text = time.getText();
                listOfTimingFromUi.add(text);
                accessWehterDetails.HorizontalSwipe(start, end, 500, 2000);
                List<MobileElement> timeListAfterScroll = accessWehterDetails.listOfTimings;
                if (timeListAfterScroll == null || timeListAfterScroll.size() == 0) {
                    break;
                }
                String firstTimeAfterScroll = timeListAfterScroll.get(0).getText().trim();
                if (firstTimeAfterScroll.equals(firstTimeBeforeScroll)) {
                    break;
                }
            }
            if (!listOfTimingFromUi.equals(listOfExpectedTiming)) {
                Assert.fail("Timing displayed is not correct");
            }




    }

    @Test
    public void verifyGovernmentScheme() {
        Tab tab = new Tab(driver);
        tab.click(tab.moreTab);
        MorePage morePage = new MorePage(driver);
        morePage.click(morePage.governMentScheme);
        GovernmentScheme governmentScheme = new GovernmentScheme(driver);

        for (int i = 0;i<3;i++) {
            governmentScheme.Verticalswipe();
        }
        if (!governmentScheme.loadMoreSchemeButton.isDisplayed()) {
            Assert.fail("Button is not present");
        }
        governmentScheme.click(governmentScheme.searchButton);
        governmentScheme.searchTextField.sendKeys("Pradhan\n");

        List<MobileElement> lisofsearch = governmentScheme.searchList;
        if (lisofsearch!= null && lisofsearch.size() >0) {
            for (MobileElement element : lisofsearch) {
                if (!element.getText().contains("Pradhan")) {
                    Assert.fail("Search dowsnot contain pradhan");
                }
            }
        } else {
            System.out.println("No search result found");
        }

    }
}
